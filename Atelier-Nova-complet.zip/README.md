# Atelier Nova

Projet de site web statique prêt à être publié.

## Contenu
- Accueil premium responsive
- Boutique et fiches produits
- Formations
- Panier avec sauvegarde locale
- Connexion / inscription de démonstration
- Espace personnel
- Centre d'aide
- Recherche simple
- Responsive mobile

## Mise en ligne
Le projet peut être publié sur GitHub Pages, Netlify ou Vercel.
Le paiement et l'authentification sont des démonstrations et doivent être connectés à un vrai service avant utilisation commerciale.
